/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable react-hooks/exhaustive-deps */
"use client";
import { useEffect, useState } from "react";
import { FolderCard, NewFolderCard } from "./components/folder-card";
import { Grid, List } from "lucide-react";
import { SegmentedControl } from "@/components/segmented-control";
import { useFolders } from "@/hooks/use-folders";
import { FolderDialog } from "./components/add-update-modal";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  createFolder,
  deleteFolder,
  updateFolder,
} from "@/services/folder.service";
import { Toolbar } from "@/components/toolbar";
import { useDebounce } from "use-debounce";
import { useRouter } from "next/navigation";
import { BreadcrumbItem, useUIStore } from "@/stores/ui.store";
import { useUserById } from "@/hooks/use-users";
import { Breadcrumbs } from "../bread-crumbs";

export function FoldersPage({ userId }: { userId?: string }) {
  const { setBreadcrumbs } = useUIStore();
  const [page] = useState(1);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedSearch] = useDebounce(searchQuery, 500);
  const [open, setOpen] = useState(false);
  const [editValues, setEditValues] = useState<{
    name: string;
    id?: string | number;
  } | null>(null);

  const { data: userDetails } = useUserById(userId, !!userId);
  const { data, isLoading, isError, error } = useFolders(
    page,
    debouncedSearch,
    userId,
  );
  const queryClient = useQueryClient();

  const router = useRouter();

  const folders = data?.items ?? [];

  const mutation = useMutation({
    mutationFn: async (data: { name: string; id?: string | number }) => {
      if (editValues) {
        await updateFolder(editValues.id as number, {
          name: data.name,
          userId,
        });
      } else {
        await createFolder(data);
      }
    },
    onError: (err) => {
      toast.error(`Error: ${err.message}`);
    },
    onSuccess: () => {
      toast.success(
        editValues
          ? "Folder updated successfully"
          : "Folder created successfully",
      );
      setOpen(false);
      setEditValues(null);
      queryClient.invalidateQueries({ queryKey: ["folders"] });
    },
  });

  const deleteMutation = useMutation({
    onSuccess: () => {
      toast.success("Folder deleted Succesfully");
      queryClient.invalidateQueries({ queryKey: ["folders"] });
    },
    onError: (error) => {
      toast.error(error.message);
    },

    mutationFn: async (id: number) => await deleteFolder(id),
  });

  useEffect(() => {
    const crumbs = [];
    if (!userId) {
      crumbs.push({ label: "Folders", href: `/admin/folders` });
    } else {
      crumbs.push({
        label: "Users",
        href: `/admin/users`,
      });
      crumbs.push({
        label: userDetails?.name,
        href: `/admin/users/${userDetails?.name}/folders`,
      });
    }
    console.log(crumbs);
    setBreadcrumbs(crumbs as BreadcrumbItem[]);
  }, [setBreadcrumbs, userDetails]);

  return (
    <main className="flex-1 transition-colors duration-150 flex flex-col gap-4 font-bold">
      <Breadcrumbs />
      <Toolbar
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        searchPlaceholder="Search folders..."
        onCreate={() => {
          setOpen(true);
        }}
        createLabel="New Folder"
        rightAddons={
          <SegmentedControl
            value={viewMode}
            onChange={setViewMode}
            options={[
              {
                value: "grid",
                label: (
                  <>
                    <Grid size={16} /> Grid
                  </>
                ),
              },
              {
                value: "list",
                label: (
                  <>
                    <List size={16} /> List
                  </>
                ),
              },
            ]}
          />
        }
      />
      <div className="flex items-center justify-between ">
        <div className="text-[21px] font-bold  tracking-wider ">
          ALL FOLDERS · {folders.length}
        </div>
      </div>

      {viewMode === "grid" ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 mb-7 font-bold">
          {folders.map((folder) => (
            <FolderCard
              key={folder.id}
              folder={folder}
              onEdit={(folder) => {
                setEditValues({ name: folder.name, id: folder.id });
                setOpen(true);
              }}
              onForward={() => {
                if (userId) {
                  router.push(`/admin/users/${userId}/folders/${folder.name}`);
                } else {
                  router.push(`/admin/folders/${folder.name}`);
                }
              }}
              onDelete={(folder) => {
                deleteMutation.mutate(folder.id);
              }}
            />
          ))}
          <NewFolderCard onClick={() => setOpen(true)} />
        </div>
      ) : (
        <div className="flex flex-col gap-2 font-bold text-lg">
          {folders.map((folder, idx) => (
            <div
              key={idx}
              className=" p-3 border  rounded-md flex items-center justify-between "
            >
              <span className="font-bold text-2xl">{folder.name}</span>
              <span className="text-2xl font-bold">{folder.qrCount} items</span>
            </div>
          ))}
        </div>
      )}
      <FolderDialog
        mode={editValues ? "edit" : "create"}
        open={open}
        onOpenChange={setOpen}
        initialName={editValues ? editValues.name : ""}
        onSubmit={async ({ name }) => {
          mutation.mutate({ name });
        }}
      />
    </main>
  );
}
