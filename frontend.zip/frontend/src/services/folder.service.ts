import { api } from "@/lib/api";
import { IApiMetaErrorStack, IApiMetaPagination, IApiResponse } from "@/types";
import { TCreateFolderDTO, TFolderDTO, TUpdateFolderDTO } from "@/types/folder";
import { AxiosError } from "axios";

interface Params {
  page: number;
  limit: number;
  search?: string;
  status?: string;
  userId?: string;
}

export async function getFolders(params: Params) {
  try {
    const res = await api.get<IApiResponse<TFolderDTO[], IApiMetaPagination>>(
      "/folders",
      {
        params,
      },
    );
    return {
      items: res.data.data,
      pagination: res.data.meta.pagination,
    };
  } catch (error: unknown) {
    const msg = (error as AxiosError<IApiResponse<null>>).response?.data
      .message;
    throw new Error(msg);
  }
}

export async function getFolderByName({ name }: { name: string }) {
  try {
    const res = await api.get<IApiResponse<TFolderDTO>>(
      "/folders/by-name/" + name,
    );
    return res.data.data;
  } catch (error) {
    const msg = (error as AxiosError<IApiResponse<null>>).response?.data
      .message;
    throw new Error(msg);
  }
}

export async function createFolder(data: TCreateFolderDTO) {
  try {
    const res = await api.post<IApiResponse<TFolderDTO>>("/folders", {
      name: data.name,
      ...(data.userId && { userId: data.userId }),
    });
    return res.data.data;
  } catch (error) {
    throw new Error(
      (error as AxiosError<IApiResponse<IApiMetaErrorStack>>).response?.data
        .message,
    );
  }
}

export async function updateFolder(
  id: number | string,
  data: TUpdateFolderDTO,
) {
  try {
    const res = await api.patch<IApiResponse<TUpdateFolderDTO>>(
      "/folders/" + id,
      {
        name: data.name,
        ...(data.userId && { userId: data.userId }),
      },
    );
    return res.data.data;
  } catch (error) {
    throw new Error(
      (error as AxiosError<IApiResponse<IApiMetaErrorStack>>).response?.data
        .message,
    );
  }
}

export async function deleteFolder(id: number | string) {
  await api.delete("/folders/" + id);
}

export async function getFolderOptions(search: string) {
  const res = await api.get<IApiResponse<{ label: string; value: number }[]>>(
    "/folders/options",
    { params: { search } },
  );
  return res.data.data;
}
