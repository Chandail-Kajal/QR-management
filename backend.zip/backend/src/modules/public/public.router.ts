import { Router } from "express";
import { findQr } from "./public.controller";
import { generateVisitorId, resolveQRDestination } from "./public.utils";
import { prisma } from "@/config/prisma";
import { QRContent } from "@/types";
import { UAParser } from "ua-parser-js";
import { z } from "zod";
import { ApiError } from "@/shared/utils";
import { updateGeolocationOnScan } from "@/shared/3rd-party/geolocaiton-ip-api";

export const qrTokenSchema = z.object({
  token: z.coerce.string().min(8, "Invalid qr token"),
});

export const publicRouter = Router();

publicRouter.get("/qr/:token", async (req, res, next) => {
  try {
    const { token } = qrTokenSchema.parse(req.params);
    const qr = await findQr(token);
    const ipAddress =
      req.headers["x-forwarded-for"]?.toString().split(",")[0] ||
      req.socket.remoteAddress;
    const userAgent = req.headers["user-agent"];
    const parser = new UAParser(userAgent);
    const result = parser.getResult();
    const language = req.header("x-language");

    const txn = await prisma.$transaction([
      prisma.qR.update({
        where: {
          id: qr.id,
        },
        data: {
          scanCount: {
            increment: 1,
          },
        },
      }),

      prisma.qRScan.create({
        data: {
          qrId: qr.id,
          ipAddress,
          userAgent,
          referer: req.headers["referer"],
          visitorId: generateVisitorId(ipAddress, userAgent),
          browser: result.browser.name,
          os: result.os.name,
          device:
            result.device.type === "mobile"
              ? "Mobile"
              : result.device.type === "tablet"
                ? "Tablet"
                : "Desktop",
          language,
        },
      }),
    ]);
    const redirectContent = resolveQRDestination(
      qr.content as unknown as QRContent,
      qr.type,
    );
    res.apiResponse(200, null, redirectContent);

    updateGeolocationOnScan(ipAddress!, txn[1].id);
  } catch (error) {
    next(error);
  }
});
