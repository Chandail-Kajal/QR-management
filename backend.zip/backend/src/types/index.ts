import { JwtPayload } from "jsonwebtoken";

export interface AuthJwtPayload extends JwtPayload {
  userId: number;
  userRole: string;
}

export type TGetOptionsProps =
  | { text: string; id?: never }
  | { id: number; text?: never };

export * from "./qr.types";
